# config.py

# --- Konfigurasi Bot Telegram ---
BOT_TOKEN = "8590574484:AAH59f8ZwkbbA0hQWT6lNznrdQagIkKJ44w" # Ganti dengan token bot kamu
OWNER_ID = 7464851361 # Ganti dengan ID Telegram kamu

# --- Konfigurasi Pengiriman Email ---
TO_EMAIL = "android@support.whatsapp.com" # Target email untuk pengiriman

# --- Konfigurasi Waktu ---
SEND_COOLDOWN_SECONDS = 5 * 60    # default 5 minutes per user between sends
REQUEST_COOLDOWN_SECONDS = 60     # 1 minute between request attempts per user
NOTIFY_OWNER_ON_SEND = True       # whether owner gets a DM when a user sends a banding
BC_DELAY_SECONDS = 0.5            # delay between broadcast messages to avoid spam limits

# --- File Persistensi ---
ALLOWED_FILE = "allowed_users.txt"
STATS_FILE = "stats.txt"
CONFIG_FILE = "config.json"
DATABASE_FILE = "database.json"

# --- UI / cosmetic ---
NEON_BORDER = "═" * 42
PROGRESS_STEPS = 8                 # animation steps (progress bar length)
ANIM_DELAY = 0.12                  # seconds between progress steps
