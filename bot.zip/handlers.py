# handlers.py

import asyncio
import json
import smtplib
import time
from datetime import datetime, timezone
from email.mime.text import MIMEText

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, filters

# Impor variabel dari bot.py dan config.py
# Kita gunakan import lokal di dalam fungsi untuk menghindari circular import
# dan karena struktur ini hanya untuk satu script bot.py utama.

async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Impor lokal
    from bot import (
        BOT_MODE, REQUEST_COOLDOWN_SECONDS, pending_requests, request_cooldowns,
        registered_chats, is_allowed, is_update_before_start, logger
    )

    try:
        chat_id = update.effective_chat.id
        registered_chats.add(chat_id)
    except Exception:
        pass

    uid = update.effective_user.id if update.effective_user else None

    mode_label = {
        "chat": "Chat Pribadi",
        "group": "Grup (Owner/Allowed Only)",
        "all": "Chat & Grup"
    }.get(BOT_MODE, BOT_MODE)

    text = (
        "👋 *Selamat Datang!*\n"
        "Bot ini membantu mengirim banding ke support WhatsApp dengan aman.\n"
        f"• *Mode:* `{mode_label}`\n"
        f"• *Cooldown /send:* `5m`\n" # Gunakan nilai dari config jika perlu
        "Gunakan /help untuk melihat perintah.\n"
    )

    try:
        await update.message.reply_text(text, parse_mode="Markdown")
    except Exception:
        await update.message.reply_text(text.replace("*", ""))

    if uid is not None and is_allowed(uid):
        try:
            await update.message.reply_text("✅ Kamu sudah punya akses. Gunakan `/send` untuk mengirim banding.", parse_mode="Markdown")
        except Exception:
            pass
        return

    if update.effective_chat and update.effective_chat.type == "private":
        last_req = request_cooldowns.get(uid, 0)
        now = time.time()
        if now - last_req < REQUEST_COOLDOWN_SECONDS:
            remain = int(REQUEST_COOLDOWN_SECONDS - (now - last_req))
            try:
                await update.message.reply_text(f"⏳ Kamu baru saja meminta akses. Tunggu {remain}s sebelum mencoba lagi.")
            except Exception:
                pass
            return

        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔔 Minta Akses ke Owner", callback_data=f"request_access:{uid}")]])
        try:
            await update.message.reply_text("🔐 Kamu belum memiliki akses. Tekan tombol untuk mengirim permintaan ke owner.", reply_markup=kb)
        except Exception:
            pass

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import BOT_MODE, OWNER_ID

    uid = update.effective_user.id if update.effective_user else None
    mode_label = {
        "chat": "Chat Pribadi",
        "group": "Grup (Owner/Allowed Only)",
        "all": "Chat & Grup"
    }.get(BOT_MODE, BOT_MODE)

    basic = (
        "📘 *Daftar Perintah (Singkat)*\n"
        "• `/myid` — Lihat ID Telegrammu\n"
        "• `/send <nomor>` — Kirim banding (contoh: `/send +62812...`)\n"
        "• `/addgmail <email> <apppw>` — Tambahkan email untuk verifikasi otomatis\n"
        "• Ketik *request* atau tekan tombol di /start untuk minta akses\n"
        f"• *Mode saat ini:* `{mode_label}`\n"
        f"• *Cooldown /send:* `5m`\n"
    )

    owner_section = ""
    if uid == OWNER_ID:
        owner_section = (
            "🔧 *Perintah Owner*\n"
            "• `/list_requests` — Lihat permintaan akses\n"
            "• `/revoke <id>` — Cabut akses user\n"
            "• `/bc <pesan>` — Broadcast ke semua allowed user\n"
            "• `/stats` — Statistik\n"
            "• `/emailstatus` — Status akun email\n"
        )

    footer = "ℹ️ *Catatan:* Saat bot di mode *group*, hanya owner & allowed users yang dapat menggunakan `/send`."

    text = basic + owner_section + footer
    try:
        await update.message.reply_text(text, parse_mode="Markdown")
    except Exception:
        await update.message.reply_text(text.replace("*", ""))

async def myid_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await update.message.reply_text(f"🪪 ID kamu: `{uid}`", parse_mode="Markdown")

async def addgmail_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import (
        TO_EMAIL, OWNER_ID, allowed_users, save_allowed, logger,
        DATABASE_FILE, load_database, save_database
    )

    uid = update.effective_user.id
    if len(context.args) < 2:
        await update.message.reply_text("❌ Format salah. Gunakan: /addgmail <email> <apppw>")
        return

    email = context.args[0].strip()
    password = " ".join(context.args[1:]).strip()

    if "@" not in email or len(password) < 8:
        await update.message.reply_text("❌ Format email atau password salah.")
        return

    db = load_database()
    user_data = db.get(str(uid), {})

    if user_data.get("status") == "approved":
        db[str(uid)] = {
            "email": email,
            "password": password,
            "status": "approved"
        }
        save_database(db)
        await update.message.reply_text("✅ Data Gmail kamu telah diperbarui dan kamu sudah memiliki akses.")
        if uid not in allowed_users:
             allowed_users.add(uid)
             save_allowed()
        return

    if user_data.get("status") == "pending":
        await update.message.reply_text("⏳ Permintaan verifikasi kamu sebelumnya masih menunggu. Silakan tunggu atau coba lagi nanti.")
        return

    # Coba verifikasi otomatis
    verification_success = send_verification_email(email, password, TO_EMAIL)

    if verification_success:
        allowed_users.add(uid)
        save_allowed()
        db[str(uid)] = {
            "email": email,
            "password": password,
            "status": "approved"
        }
        save_database(db)
        await update.message.reply_text("✅ Verifikasi otomatis berhasil! Akses kamu telah diaktifkan.")
        logger.info(f"User {uid} ({update.effective_user.full_name}) mendapat akses otomatis melalui /addgmail.")
    else:
        db[str(uid)] = {
            "email": email,
            "password": password,
            "status": "pending"
        }
        save_database(db)
        await update.message.reply_text("📧 Data Gmail kamu disimpan. Permintaan verifikasi otomatis gagal, tetapi data kamu akan dikirim ke owner untuk ditinjau. Silakan menunggu.")

def send_verification_email(email, password, target_email):
    """Mengirim email verifikasi ke target_email menggunakan akun yang diberikan."""
    subject = "y"
    body = "y"
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = email
    msg["To"] = target_email

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=25) as server:
            server.login(email, password)
            server.sendmail(email, target_email, msg.as_string())
        return True
    except Exception as e:
        # Logging dilakukan di handler
        return False

async def request_access_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import (
        OWNER_ID, allowed_users, save_allowed, pending_requests, request_cooldowns,
        load_database, is_allowed, is_update_before_start, logger
    )

    if is_update_before_start(update):
        try:
            await update.callback_query.answer()
            await update.callback_query.message.reply_text("⚠️ Tombol ini diklik dari pesan lama (bot baru hidup). Silakan tekan lagi.")
        except Exception:
            pass
        return

    query = update.callback_query
    if not query:
        return
    await query.answer()

    data = query.data or ""
    if not data.startswith("request_access:"):
        await query.edit_message_text("⚠️ Data invalid.")
        return

    try:
        uid = int(data.split(":", 1)[1])
    except:
        await query.edit_message_text("⚠️ Data invalid (uid).")
        return

    if query.from_user.id != uid:
        await query.edit_message_text("⚠️ Tombol ini bukan untukmu.")
        return

    if is_allowed(uid):
        await query.edit_message_text("✅ Kamu sudah terdaftar.")
        return

    db = load_database()
    user_data = db.get(str(uid), {})
    if user_data.get("status") == "approved":
        allowed_users.add(uid)
        save_allowed()
        await query.edit_message_text("✅ Akses kamu sebelumnya telah disetujui secara otomatis. Kamu sekarang memiliki akses.")
        return

    if uid in pending_requests:
        await query.edit_message_text("⏳ Permintaanmu sudah dikirim ke owner; tunggu persetujuan.")
        return

    now = time.time()
    last_req = request_cooldowns.get(uid, 0)
    if now - last_req < 60: # Gunakan REQUEST_COOLDOWN_SECONDS jika diimpor
        remain = int(60 - (now - last_req))
        await query.edit_message_text(f"⏳ Kamu baru meminta akses. Tunggu {remain}s.")
        return

    requester_name = query.from_user.full_name or query.from_user.username or str(uid)
    request_text = (
        f"🔔 *Permintaan Akses Baru*\n"
        f"👤 Nama: `{requester_name}`\n"
        f"🆔 ID: `{uid}`\n"
        f"🕐 Waktu: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
        "Tekan ✅ ACC untuk memberikan akses atau ❌ TOLAK untuk menolak."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ ACC", callback_data=f"owner_decision:approve:{uid}")],
        [InlineKeyboardButton("❌ TOLAK", callback_data=f"owner_decision:reject:{uid}")],
    ])

    try:
        await context.bot.send_message(chat_id=OWNER_ID, text=request_text, parse_mode="Markdown", reply_markup=kb)
        pending_requests.add(uid)
        request_cooldowns[uid] = now
        await query.edit_message_text("✅ Permintaan akses telah dikirim ke owner. Tunggu persetujuan.")
        logger.info(f"Access request sent to owner for uid={uid}")
    except Exception as e:
        logger.warning(f"Failed to send request to owner: {e}")
        await query.edit_message_text("❌ Gagal mengirim permintaan ke owner; coba lagi nanti.")

async def owner_decision_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import (
        OWNER_ID, allowed_users, save_allowed, pending_requests,
        load_database, save_database, is_allowed, is_update_before_start, logger
    )

    if is_update_before_start(update):
        try:
            await update.callback_query.answer()
            await update.callback_query.message.reply_text("⚠️ Tombol ini diklik dari pesan lama (bot baru hidup). Silakan buka permintaan baru.")
        except Exception:
            pass
        return

    query = update.callback_query
    if not query:
        return
    await query.answer()

    data = query.data or ""
    parts = data.split(":")
    if len(parts) != 3:
        await query.edit_message_text("⚠️ Data invalid.")
        return

    action, decision, uid_str = parts
    if action != "owner_decision":
        await query.edit_message_text("⚠️ Data invalid.")
        return

    try:
        target_uid = int(uid_str)
    except:
        await query.edit_message_text("⚠️ UID invalid.")
        return

    if query.from_user.id != OWNER_ID:
        await query.edit_message_text("🚫 Hanya owner yang bisa melakukan ini.")
        return

    if decision == "approve":
        allowed_users.add(target_uid)
        save_allowed()
        pending_requests.discard(target_uid)
        db = load_database()
        if str(target_uid) in db:
            db[str(target_uid)]["status"] = "approved"
            save_database(db)
        await query.edit_message_text(f"✅ ID `{target_uid}` telah di-ACC.", parse_mode="Markdown")
        try:
            await context.bot.send_message(chat_id=target_uid, text="✅ Permintaan akses disetujui. Kamu sekarang dapat menggunakan /send.")
        except Exception:
            logger.info(f"Could not DM approved user {target_uid}")
        logger.info(f"Owner approved uid={target_uid}")

    elif decision == "reject":
        pending_requests.discard(target_uid)
        db = load_database()
        if str(target_uid) in db:
            db[str(target_uid)]["status"] = "rejected"
            save_database(db)
        await query.edit_message_text(f"❌ ID `{target_uid}` ditolak.", parse_mode="Markdown")
        try:
            await context.bot.send_message(chat_id=target_uid, text="❌ Permintaan akses ditolak oleh owner.")
        except Exception:
            logger.info(f"Could not DM rejected user {target_uid}")
        logger.info(f"Owner rejected uid={target_uid}")
    else:
        await query.edit_message_text("⚠️ Aksi tidak dikenali.")

async def send_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import (
        SEND_COOLDOWN_SECONDS, TO_EMAIL, NOTIFY_OWNER_ON_SEND, OWNER_ID,
        active_accounts, email_status, current_account_index,
        stats, save_stats, user_last_send,
        is_allowed, is_update_before_start, logger
    )
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn

    uid = update.effective_user.id

    if not is_allowed(uid):
        return await update.message.reply_text("🚫 Kamu belum diberi akses. Tekan /start lalu minta akses ke owner atau gunakan /addgmail.")

    if not context.args:
        return await update.message.reply_text("✍️ Gunakan: /send +62xxxxxxxxx")

    number = context.args[0].strip()
    now = time.time()
    last_send = user_last_send.get(uid, 0)
    if now - last_send < SEND_COOLDOWN_SECONDS:
        remain = int(SEND_COOLDOWN_SECONDS - (now - last_send))
        return await update.message.reply_text(f"⏳ Kamu baru saja mengirim banding. Tunggu {remain}s sebelum mengirim lagi.")

    # Ambil akun email berikutnya
    account = get_next_active_account()
    if not account:
        logger.error("Tidak ada akun email aktif tersisa untuk digunakan.")
        return await update.message.reply_text("❌ Gagal mengirim: Tidak ada akun email aktif.")

    sending_msg = await update.message.reply_text("🚀 Mengirim banding • [          ] 0%")
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task(description="Mengirim...", total=None)
            for i in range(1, 9): # 8 langkah animasi
                pct = int((i / 8) * 100)
                bar = "█" * i + " " * (8 - i)
                await asyncio.sleep(0.12) # ANIM_DELAY
                try:
                    await sending_msg.edit_text(f"🚀 Mengirim banding • [{bar}] {pct}%")
                except Exception:
                    pass
                progress.update(task, advance=1)

        # Kirim email
        msg = MIMEText(f"Hello WhatsApp Support,\nrequests activation for the number: {number}.\nDetails: The user reports that verification returns 'number cannot be registered'. Please reactivate my number so it can be verified.  \nBest regard, Sakuraa")
        msg["Subject"] = "Request for Activation – My WhatsApp Number Cannot Be Registered"
        msg["From"] = account["email"]
        msg["To"] = TO_EMAIL

        ok, err = await asyncio.get_running_loop().run_in_executor(None, send_email_with_account, msg, account)

        if ok:
            user_last_send[uid] = now
            stats["sent"] += 1
            stats["users"].add(uid)
            stats["numbers"].add(number)
            stats["user_counts"][uid] = stats["user_counts"].get(uid, 0) + 1
            save_stats()
            await sending_msg.edit_text(f"✅ Banding terkirim untuk {number} — Kiriman 1 / 1 (selama {SEND_COOLDOWN_SECONDS}s)")
            logger.info(f"Sent appeal for {number} by {uid} using {account['email']}")

            email_status[account["email"]] = True

            if NOTIFY_OWNER_ON_SEND:
                try:
                    notify_text = (
                        f"📣 *Banding Terkirim*\n"
                        f"👤 User: `{update.effective_user.full_name or update.effective_user.username or uid}`\n"
                        f"🆔 ID: `{uid}`\n"
                        f"📧 Via: {account['email']}\n"
                        f"📱 Nomor: {number}\n"
                        f"🕐 Waktu: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}"
                    )
                    await context.bot.send_message(chat_id=OWNER_ID, text=notify_text, parse_mode="Markdown")
                except Exception:
                    logger.info(f"Could not notify owner about send by {uid}")
        else:
            stats["failed"] += 1
            save_stats()
            await sending_msg.edit_text("❌ Gagal mengirim banding. Coba lagi nanti.")
            logger.warning(f"SMTP error using {account['email']}: {err}")

            email_status[account["email"]] = False
            if account in active_accounts:
                active_accounts.remove(account)
                logger.info(f"Akun {account['email']} dihapus dari rotasi karena gagal.")

    except Exception as e:
        logger.exception(f"Error in sending flow: {e}")
        try:
            await sending_msg.edit_text("❌ Terjadi kesalahan saat pengiriman.")
        except Exception:
            pass

def send_email_with_account(msg, account):
    try:
        with smtplib.SMTP_SSL(account["smtp_server"], account["smtp_port"], timeout=25) as server:
            server.login(account["email"], account["password"])
            server.sendmail(account["email"], account["target_email"], msg.as_string())
        return True, None
    except Exception as e:
        return False, str(e)

def get_next_active_account():
    from bot import active_accounts, email_status, current_account_index
    if not active_accounts:
        return None

    for _ in range(len(active_accounts)):
        account = active_accounts[current_account_index]
        if email_status.get(account["email"], True):
            current_account_index = (current_account_index + 1) % len(active_accounts)
            return account
        current_account_index = (current_account_index + 1) % len(active_accounts)
    return None

async def list_requests_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import OWNER_ID, pending_requests

    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("🚫 Hanya owner yang bisa melihat permintaan.")
    if not pending_requests:
        return await update.message.reply_text("✅ Tidak ada permintaan saat ini.")
    text = "🔔 *Pending Requests:*\n" + "\n".join(f"- `{uid}`" for uid in sorted(pending_requests))
    await update.message.reply_text(text, parse_mode="Markdown")

async def revoke_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import OWNER_ID, allowed_users, save_allowed, load_database, save_database

    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("🚫 Hanya owner yang bisa mencabut akses.")
    if not context.args:
        return await update.message.reply_text("✍️ Gunakan: /revoke <user_id>")
    try:
        target = int(context.args[0])
    except:
        return await update.message.reply_text("⚠️ ID tidak valid.")
    if target in allowed_users:
        allowed_users.remove(target)
        save_allowed()
        db = load_database()
        if str(target) in db:
            db[str(target)]["status"] = "revoked"
            save_database(db)
        await update.message.reply_text(f"✅ Akses ID `{target}` dicabut.", parse_mode="Markdown")
        try:
            await context.bot.send_message(chat_id=target, text="⚠️ Akses kamu telah dicabut oleh owner.")
        except Exception:
            pass
    else:
        await update.message.reply_text("ℹ️ ID tidak ada di daftar akses.")

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import OWNER_ID, stats

    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("🚫 Hanya owner yang bisa melihat statistik.")
    sent = stats["sent"]
    failed = stats["failed"]
    total_users = len(stats["users"])
    total_numbers = len(stats["numbers"])
    text = (
        f"📊 Statistik\n"
        f"✅ Sent: {sent}\n"
        f"❌ Failed: {failed}\n"
        f"👥 Users unique: {total_users}\n"
        f"📱 Numbers unique: {total_numbers}\n"
    )
    await update.message.reply_text(text)

async def emailstatus_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import OWNER_ID, ACCOUNTS, email_status
    from rich.console import Console
    from rich.table import Table

    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("🚫 Hanya owner yang bisa melihat status email.")
    console = Console()
    table = Table(title="Status Akun Email")
    table.add_column("Email", style="cyan", no_wrap=True)
    table.add_column("Status", style="magenta")

    for acc in ACCOUNTS:
        email = acc["email"]
        status = "BERHASIL" if email_status.get(email, False) else "GAGAL"
        style = "green" if status == "BERHASIL" else "red"
        table.add_row(email, status, style=style)

    console.print(table)
    await update.message.reply_text("📋 Status akun email telah dicetak di terminal.")

async def bc_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from bot import OWNER_ID, allowed_users, BC_DELAY_SECONDS

    if update.effective_user.id != OWNER_ID:
        return await update.message.reply_text("🚫 Hanya owner yang bisa broadcast.")
    if not context.args:
        return await update.message.reply_text("✍️ Gunakan: /bc <pesan>")
    message = " ".join(context.args)
    users = sorted(allowed_users)
    if not users:
        return await update.message.reply_text("⚠️ Belum ada user terdaftar.")
    await update.message.reply_text(f"📢 Mengirim ke {len(users)} user (mulai)...")
    success = 0
    for uid in users:
        try:
            await context.bot.send_message(uid, f"📢 *Broadcast Owner*\n{message}", parse_mode="Markdown")
            success += 1
            await asyncio.sleep(BC_DELAY_SECONDS)
        except Exception as e:
            logger.warning(f"Failed BC to {uid}: {e}")
    await update.message.reply_text(f"✅ Broadcast selesai: {success}/{len(users)} sukses.")

async def request_shortcut_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start_cmd(update, context)
