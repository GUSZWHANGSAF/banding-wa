from __future__ import annotations
import os
import time
import json
import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict, Optional, Set
import os, sys, atexit, signal

# --- Setup Rich Console dan Logging ---
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.logging import RichHandler
from rich import print as rprint
from rich.panel import Panel
from rich.text import Text

console = Console()
logger = logging.getLogger("VaniiSwaan")
logger.setLevel(logging.INFO)

if logger.hasHandlers():
    logger.handlers.clear()
rich_handler = RichHandler(
    console=console,
    show_path=False,
    markup=True,
    rich_tracebacks=True
)
rich_handler.setFormatter(logging.Formatter(fmt="%(message)s", datefmt="[%X]"))
logger.addHandler(rich_handler)

# --- Impor Konfigurasi dari config.py ---
try:
    from config import (
        BOT_TOKEN,
        OWNER_ID,
        TO_EMAIL,
        SEND_COOLDOWN_SECONDS,
        REQUEST_COOLDOWN_SECONDS,
        NOTIFY_OWNER_ON_SEND,
        BC_DELAY_SECONDS,
        ALLOWED_FILE,
        STATS_FILE,
        CONFIG_FILE,
        DATABASE_FILE,
        NEON_BORDER,
        PROGRESS_STEPS,
        ANIM_DELAY,
    )
except ImportError:
    print("File config.py tidak ditemukan. Silakan buat file config.py terlebih dahulu.")
    sys.exit()

# --- Daftar Akun Email (Digabungkan) ---
ACCOUNTS = [
    # Akun asli dari script sebelumnya
    {"email": "bandingmerah763@gmail.com", "password": "yqjd zbkc xclz ubwd", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "malzoffcial5009@gmail.com", "password": "iebj mqgx xjuk wfs", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "v8728799@gmail.com", "password": "wjng geyu qrjb qrkz", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "zarkm07@gmail.com", "password": "iids tqgr mopb zxf", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "zarkymark7@gmail.com", "password": "jlem mvwf nsog bvpq", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    # Akun baru dari data JSON (format password diperbaiki)
    {"email": "emailalert37@gmail.com", "password": "dzzp mevt uexf eagc", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "0Anonymusy1@gmail.com", "password": "fvin nkbd tcrv wakf", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonymusy101@gmail.com", "password": "yctg uthl wnrv pful", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "heckedbyx1@gmail.com", "password": "ibdf ukbz ugqd fqwu", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "sonin.spd01@gmail.com", "password": "fkpp cyay qfdb syll", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonymusyid909@gmail.com", "password": "gtcx gwtc yzfp aimi", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonimousee909@gmail.com", "password": "vwsz udcr zwtn nddt", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonimouse90909@gmail.com", "password": "hhgl fmji jsae sqxu", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonimouse9099@gmail.com", "password": "qpss riuo pkjk tmeg", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonimouse90999@gmail.com", "password": "ijrf hhuo jpml iysc", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "aaabaaah2@gmail.com", "password": "oqtx elxg cefv dgvd", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anjaynathan399@gmail.com", "password": "cpil kwkt llab sodh", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "joeellan26@gmail.com", "password": "wnfe iboi ktrr uder", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "bayarutangllu@gmail.com", "password": "cbty vvaf rncu oawg", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "cindyfiolita9@gmail.com", "password": "kpvu treo hfar zqdy", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "anonymousgalirus@gmail.com", "password": "ltnc fedd qzsy lfwu", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "gstorekonter4@gmail.com", "password": "xwdq ugie fbjw xeaa", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "makluetekerbpaluhekel@gmail.com", "password": "oyys dexg uofj vhkt", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "fire.send482@gmail.com", "password": "dpus bvni hmvn caob", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "auto.send583@gmail.com", "password": "awlg kpsu rszi fppt", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "jiki.mioli08@gmail.com", "password": "gzwj sohl dzxd pteh", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    # Akun tambahan dari data JSON kamu
    {"email": "tayotayooxirf@gmail.com", "password": "edpj gvcx fehp rtfl", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "tayo404tayyo404@gmail.com", "password": "jeat hezh ditz akuk", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "irfafitrio@gmail.com", "password": "khtm tnxz nbey ahue", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "sigmamewing1232@gmail.com", "password": "trzs dett smbl iykw", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "joyditiano9@gmail.com", "password": "rnfv nfqa ggcf lyqn", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "draid6247@gmail.com", "password": "dhwm abuc vkan sof", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "daemontechx@gmail.com", "password": "jxov iorq ztpw hirz", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "daemoniumuserv2@gmail.com", "password": "yexa nkvy ghqh hsbd", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "daemoniumuser@gmail.com", "password": "wgas iris atyy xpnc", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "c26898771@gmail.com", "password": "ykky jurs pvqq kmhj", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "rizkicuaca62@gmail.com", "password": "azud gild ptqm ooop", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "bunawarhadi@gmail.com", "password": "qhub vsfb oytb qqoa", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "gutodoang@gmail.com", "password": "rcer clrw tckg ppea", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "bocahbebanbocahbeban@gmail.com", "password": "fdye aial ngai clqp", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "siniluanjing484@gmail.com", "password": "chji sayr htkq wjjz", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
    {"email": "qoegvnv@gmail.com", "password": "ueha fbsz unmb jqzj", "smtp_server": "smtp.gmail.com", "smtp_port": 465, "target_email": TO_EMAIL},
]

# --- Impor Telegram (diasumsikan sudah terinstal) ---
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# --- Impor Handler dari handlers.py ---
from handlers import (
    start_cmd,
    help_cmd,
    myid_cmd,
    addgmail_cmd,
    request_access_callback,
    owner_decision_callback,
    send_cmd,
    list_requests_cmd,
    revoke_cmd,
    stats_cmd,
    emailstatus_cmd,
    bc_cmd,
    request_shortcut_handler
)

# --- Fungsi Bantuan ---
def neon_header() -> str:
    return f"{NEON_BORDER}\nFUCK YOUR MOMS\n{NEON_BORDER}"

def is_allowed(uid: int) -> bool:
    return uid in allowed_users or uid == OWNER_ID

def is_update_before_start(update: Update) -> bool:
    """
    Return True if the update originates from a message/callback that was created
    before the bot started (i.e., sent while bot was offline).
    """
    if BOT_START_TIME is None:
        return False
    msg = update.effective_message
    if msg and getattr(msg, "date", None):
        try:
            msg_date = msg.date
            if msg_date.tzinfo is None:
                 msg_date = msg_date.replace(tzinfo=timezone.utc)
            if msg_date < BOT_START_TIME:
                return True
        except Exception:
            pass
    if update.callback_query and update.callback_query.message and getattr(update.callback_query.message, "date", None):
        try:
            cbq_msg_date = update.callback_query.message.date
            if cbq_msg_date.tzinfo is None:
                 cbq_msg_date = cbq_msg_date.replace(tzinfo=timezone.utc)
            if cbq_msg_date < BOT_START_TIME:
                return True
        except Exception:
            pass
    return False

# --- Fungsi Load/Save ---
def load_allowed() -> Set[int]:
    s = set()
    if os.path.exists(ALLOWED_FILE):
        try:
            with open(ALLOWED_FILE, "r") as f:
                for line in f:
                    t = line.strip()
                    if t.isdigit():
                        s.add(int(t))
        except Exception as e:
            logger.warning(f"Failed reading allowed file: {e}")
    return s

def save_allowed():
    try:
        with open(ALLOWED_FILE, "w") as f:
            for uid in sorted(allowed_users):
                f.write(f"{uid}\n")
    except Exception as e:
        logger.warning(f"Failed saving allowed file: {e}")

def load_stats():
    global stats
    if not os.path.exists(STATS_FILE):
        return
    try:
        with open(STATS_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if not line or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k in ("sent", "failed"):
                    try:
                        stats[k] = int(v)
                    except:
                        stats[k] = 0
                elif k == "users":
                    stats["users"] = set(map(int, v.split(","))) if v else set()
                elif k == "numbers":
                    stats["numbers"] = set(v.split(",")) if v else set()
                elif k == "user_counts":
                    d = {}
                    if v:
                        for item in v.split(","):
                            if ":" in item:
                                a, b = item.split(":", 1)
                                try:
                                    d[int(a)] = int(b)
                                except:
                                    pass
                    stats["user_counts"] = d
    except Exception as e:
        logger.warning(f"Failed loading stats: {e}")

def save_stats():
    try:
        with open(STATS_FILE, "w") as f:
            f.write(f"sent={stats['sent']}\n")
            f.write(f"failed={stats['failed']}\n")
            f.write(f"users={','.join(map(str, stats['users']))}\n")
            f.write(f"numbers={','.join(stats['numbers'])}\n")
            f.write(f"user_counts={','.join(f'{k}:{v}' for k, v in stats['user_counts'].items())}\n")
    except Exception as e:
        logger.warning(f"Failed saving stats: {e}")

def load_database():
    """Memuat data pengguna dari database.json."""
    if not os.path.exists(DATABASE_FILE):
        return {}
    try:
        with open(DATABASE_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Failed loading database.json: {e}")
        return {}

def save_database(data):
    """Menyimpan data pengguna ke database.json."""
    try:
        with open(DATABASE_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.warning(f"Failed saving database.json: {e}")

def load_config():
    """Load BOT_MODE and SEND_COOLDOWN_SECONDS from CONFIG_FILE if exists."""
    global BOT_MODE, SEND_COOLDOWN_SECONDS
    if not os.path.exists(CONFIG_FILE):
        return
    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
        mode = data.get("mode")
        if mode in ("chat", "group", "all"):
            BOT_MODE = mode
        cd = data.get("send_cooldown_seconds")
        if isinstance(cd, int) and cd >= 0:
            SEND_COOLDOWN_SECONDS = cd
        logger.info(f"Loaded config: mode={BOT_MODE} send_cooldown={SEND_COOLDOWN_SECONDS}")
    except Exception as e:
        logger.warning(f"Failed loading config.json: {e}")

# --- Variabel Runtime ---
BOT_START_TIME: datetime = None
allowed_users: Set[int] = set()
pending_requests: Set[int] = set()
request_cooldowns: Dict[int, float] = {}
user_last_send: Dict[int, float] = {}
stats = {"sent": 0, "failed": 0, "users": set(), "numbers": set(), "user_counts": {}}

registered_chats: Set[int] = set()
BOT_MODE = "chat"

# --- Email Account Management ---
active_accounts = ACCOUNTS.copy()
email_status: Dict[str, bool] = {acc["email"]: True for acc in ACCOUNTS}
current_account_index = 0

# --- Inisialisasi ---
allowed_users = load_allowed()
load_stats()
load_config()
BOT_START_TIME = datetime.now(timezone.utc)

logger.info(neon_header())

# --- Setup Application ---
app = Application.builder().token(BOT_TOKEN).build()

# --- Register Handlers ---
app.add_handler(CommandHandler("start", start_cmd))
app.add_handler(CommandHandler("help", help_cmd))
app.add_handler(CommandHandler("myid", myid_cmd))
app.add_handler(CommandHandler("addgmail", addgmail_cmd))
app.add_handler(CommandHandler("send", send_cmd))
app.add_handler(CommandHandler("list_requests", list_requests_cmd))
app.add_handler(CommandHandler("revoke", revoke_cmd))
app.add_handler(CommandHandler("stats", stats_cmd))
app.add_handler(CommandHandler("bc", bc_cmd))
app.add_handler(CommandHandler("emailstatus", emailstatus_cmd))

app.add_handler(CallbackQueryHandler(request_access_callback, pattern=r"^request_access:"))
app.add_handler(CallbackQueryHandler(owner_decision_callback, pattern=r"^owner_decision:"))

app.add_handler(MessageHandler(filters.Regex(r"(?i)^\s*request\s*$"), request_shortcut_handler))

# --- Jalankan Bot ---
if __name__ == "__main__":
    logger.info(f"Bot starting... (mode={BOT_MODE})")
    app.run_polling()
